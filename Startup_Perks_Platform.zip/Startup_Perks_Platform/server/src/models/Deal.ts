import mongoose, { Document, Schema } from 'mongoose';

export interface IDeal extends Document {
  title: string;
  description: string;
  partnerName: string;
  category: string;
  isLocked: boolean;
  logoUrl?: string;
  eligibility: string;
  createdAt: Date;
}

const DealSchema: Schema = new Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  partnerName: { type: String, required: true },
  category: { type: String, required: true }, // e.g., 'Cloud', 'Marketing', 'DevTools'
  isLocked: { type: Boolean, default: false },
  logoUrl: { type: String },
  eligibility: { type: String, required: true },
}, { timestamps: true });

export default mongoose.model<IDeal>('Deal', DealSchema);
