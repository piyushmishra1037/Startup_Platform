import { Response } from 'express';
import Claim from '../models/Claim';
import Deal from '../models/Deal';
import User from '../models/User';
import { AuthRequest } from '../middleware/authMiddleware';

export const claimDeal = async (req: AuthRequest, res: Response) => {
  const { dealId } = req.body;
  const userId = req.user.id;

  try {
    const deal = await Deal.findById(dealId);
    if (!deal) {
      return res.status(404).json({ message: 'Deal not found' });
    }

    const user = await User.findById(userId);
    if (!user) {
        return res.status(404).json({ message: 'User not found' });
    }

    // Check restriction
    if (deal.isLocked && !user.isVerified) {
      return res.status(403).json({ message: 'User must be verified to claim this deal' });
    }

    // Check if already claimed
    const existingClaim = await Claim.findOne({ user: userId, deal: dealId });
    if (existingClaim) {
      return res.status(400).json({ message: 'You have already claimed this deal' });
    }

    const claim = await Claim.create({
      user: userId,
      deal: dealId,
      status: 'approved', // Auto-approve for now, or could be 'pending'
    });

    res.status(201).json(claim);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Server error' });
  }
};

export const getMyClaims = async (req: AuthRequest, res: Response) => {
  try {
    const claims = await Claim.find({ user: req.user.id }).populate('deal');
    res.json(claims);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
};
