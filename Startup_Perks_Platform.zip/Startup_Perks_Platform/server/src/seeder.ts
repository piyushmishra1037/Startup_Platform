import mongoose from 'mongoose';
import dotenv from 'dotenv';
import connectDB from './config/db';
import Deal from './models/Deal';
import User from './models/User';
import Claim from './models/Claim';

dotenv.config();

connectDB();

const deals = [
  {
    title: 'AWS Activate',
    description: '$5,000 in AWS credits for 2 years.',
    partnerName: 'Amazon Web Services',
    category: 'Cloud',
    isLocked: true,
    eligibility: 'Must be a funded startup.',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/9/93/Amazon_Web_Services_Logo.svg'
  },
  {
    title: 'HubSpot for Startups',
    description: '30% off HubSpot Growth Suite.',
    partnerName: 'HubSpot',
    category: 'Marketing',
    isLocked: false,
    eligibility: 'New customers only.',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/3/3f/HubSpot_Logo.svg'
  },
  {
    title: 'Notion Plus',
    description: '6 months free of Notion Plus with AI.',
    partnerName: 'Notion',
    category: 'Productivity',
    isLocked: false,
    eligibility: 'Less than 50 employees.',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/4/45/Notion_app_logo.png'
  },
  {
    title: 'Stripe Atlas',
    description: '50% off Stripe Atlas incorporation.',
    partnerName: 'Stripe',
    category: 'Finance',
    isLocked: true,
    eligibility: 'Incorporating in Delaware.',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/b/ba/Stripe_Logo%2C_revised_2016.svg'
  },
   {
    title: 'Linear',
    description: 'Linear for Startups: 6 months free on the Standard plan.',
    partnerName: 'Linear',
    category: 'Productivity',
    isLocked: false,
    eligibility: 'Early stage startups.',
    logoUrl: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c8/Linear_logo.svg/1200px-Linear_logo.svg.png'
  },
  {
    title: 'Vercel Pro',
    description: '$600 in credits for Vercel Pro.',
    partnerName: 'Vercel',
    category: 'Cloud',
    isLocked: true,
    eligibility: 'Pro plan users.',
    logoUrl: 'https://assets.vercel.com/image/upload/v1588805858/repositories/vercel/logo.png'
  }
];

const importData = async () => {
  try {
    await Deal.deleteMany();
    await Claim.deleteMany();
    // await User.deleteMany(); // Optional: keep users

    await Deal.insertMany(deals);

    console.log('Data Imported!');
    process.exit();
  } catch (error) {
    console.error(`${error}`);
    process.exit(1);
  }
};

const destroyData = async () => {
  try {
    await Deal.deleteMany();
    await Claim.deleteMany();
    // await User.deleteMany();

    console.log('Data Destroyed!');
    process.exit();
  } catch (error) {
    console.error(`${error}`);
    process.exit(1);
  }
};

if (process.argv[2] === '-d') {
  destroyData();
} else {
  importData();
}
