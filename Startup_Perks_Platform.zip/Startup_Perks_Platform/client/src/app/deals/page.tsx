'use client';

import { useState, useEffect } from 'react';
import api from '../../lib/api';
import DealCard from '../../components/DealCard';
import { useAuth } from '../../context/AuthContext';
import { motion } from 'framer-motion';
import { Search, Filter, Loader2 } from 'lucide-react';

interface Deal {
  _id: string;
  title: string;
  description: string;
  partnerName: string;
  category: string;
  isLocked: boolean;
  logoUrl?: string;
  eligibility: string;
}

export default function Deals() {
  const [deals, setDeals] = useState<Deal[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all'); // all, locked, unlocked

  useEffect(() => {
    const fetchDeals = async () => {
      try {
        const { data } = await api.get('/deals');
        setDeals(data);
      } catch (error) {
        console.error('Error fetching deals:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchDeals();
  }, []);

  const filteredDeals = deals.filter(deal => {
    const matchesSearch = deal.title.toLowerCase().includes(search.toLowerCase()) || 
                          deal.partnerName.toLowerCase().includes(search.toLowerCase());
    const matchesFilter = filter === 'all' ? true : 
                          filter === 'locked' ? deal.isLocked : !deal.isLocked;
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="min-h-screen relative bg-slate-950 pt-24 pb-12">
        <div className="absolute inset-0 z-0 bg-grid-pattern opacity-10 pointer-events-none" />
        
        <div className="container mx-auto px-6 relative z-10">
            <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mb-12 text-center max-w-2xl mx-auto"
            >
                <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-b from-white to-slate-400">
                    Available Perks
                </h1>
                <p className="text-slate-400 text-lg">
                    Curated deals to help you build, launch, and scale faster.
                </p>
            </motion.div>

            {/* Search & Filter Bar */}
            <div className="max-w-4xl mx-auto mb-12">
                <div className="glass-panel p-2 rounded-2xl flex flex-col md:flex-row gap-2">
                    <div className="relative flex-1">
                        <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-500" size={20} />
                        <input 
                            type="text" 
                            placeholder="Search partners, deals, or categories..." 
                            className="w-full bg-transparent border-none text-white placeholder-slate-500 rounded-xl pl-12 pr-4 py-3 focus:ring-0"
                            value={search}
                            onChange={(e) => setSearch(e.target.value)}
                        />
                    </div>
                    <div className="flex items-center border-l border-white/10 pl-2 md:w-48">
                         <Filter className="text-slate-500 ml-2" size={16} />
                         <select 
                            className="w-full bg-transparent border-none text-slate-300 focus:ring-0 cursor-pointer py-3 text-sm"
                            value={filter}
                            onChange={(e) => setFilter(e.target.value)}
                        >
                            <option value="all" className="bg-slate-900">All Deals</option>
                            <option value="unlocked" className="bg-slate-900">Public Access</option>
                            <option value="locked" className="bg-slate-900">Verified Only</option>
                        </select>
                    </div>
                </div>
            </div>

            {loading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {[1, 2, 3, 4, 5, 6].map((i) => (
                        <div key={i} className="glass-panel h-64 rounded-xl animate-pulse p-6">
                            <div className="flex justify-between mb-6">
                                <div className="w-12 h-12 bg-white/5 rounded-lg"></div>
                                <div className="w-16 h-6 bg-white/5 rounded-full"></div>
                            </div>
                            <div className="h-6 bg-white/5 rounded w-3/4 mb-3"></div>
                            <div className="h-4 bg-white/5 rounded w-full mb-2"></div>
                            <div className="h-4 bg-white/5 rounded w-1/2"></div>
                        </div>
                    ))}
                </div>
            ) : (
                <>
                    {filteredDeals.length > 0 ? (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {filteredDeals.map((deal, idx) => (
                                <motion.div
                                    key={deal._id}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    transition={{ delay: idx * 0.05 }}
                                >
                                    <DealCard deal={deal} isVerified={user?.isVerified || false} />
                                </motion.div>
                            ))}
                        </div>
                    ) : (
                        <div className="text-center py-20">
                            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-white/5 mb-4">
                                <Search className="text-slate-500" size={24} />
                            </div>
                            <h3 className="text-xl font-bold text-white mb-2">No deals found</h3>
                            <p className="text-slate-400">Try adjusting your search or filters.</p>
                        </div>
                    )}
                </>
            )}
        </div>
    </div>
  );
}
