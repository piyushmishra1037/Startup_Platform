'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import api from '../../../lib/api';
import { useAuth } from '../../../context/AuthContext';
import { motion } from 'framer-motion';
import { Lock, CheckCircle, AlertCircle, ArrowLeft, ShieldCheck, Globe, Calendar } from 'lucide-react';
import Link from 'next/link';
import clsx from 'clsx';

interface Deal {
  _id: string;
  title: string;
  description: string;
  partnerName: string;
  category: string;
  isLocked: boolean;
  logoUrl?: string;
  eligibility: string;
}

export default function DealDetails() {
  const { id } = useParams();
  const [deal, setDeal] = useState<Deal | null>(null);
  const [loading, setLoading] = useState(true);
  const [claiming, setClaiming] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  const { user } = useAuth();
  const router = useRouter();

  useEffect(() => {
    const fetchDeal = async () => {
      try {
        const { data } = await api.get(`/deals/${id}`);
        setDeal(data);
      } catch (error) {
        console.error('Error fetching deal:', error);
      } finally {
        setLoading(false);
      }
    };
    if (id) fetchDeal();
  }, [id]);

  const handleClaim = async () => {
    if (!user) {
      router.push('/login');
      return;
    }
    
    setClaiming(true);
    setMessage(null);

    try {
      await api.post('/claims', { dealId: deal?._id });
      setMessage({ type: 'success', text: 'Deal claimed successfully! Check your dashboard.' });
    } catch (error: any) {
      setMessage({ type: 'error', text: error.response?.data?.message || 'Failed to claim deal.' });
    } finally {
      setClaiming(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center pt-20">
        <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!deal) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center pt-20 text-center px-6">
        <h2 className="text-3xl font-bold mb-4">Deal Not Found</h2>
        <p className="text-slate-400 mb-8">The deal you are looking for might have been removed or expires.</p>
        <Link href="/deals">
          <button className="bg-white text-black px-6 py-3 rounded-full font-bold hover:bg-slate-200 transition-colors">
            Browse All Deals
          </button>
        </Link>
      </div>
    );
  }

  const canClaim = !deal.isLocked || (user && user.isVerified);

  return (
    <div className="min-h-screen pt-24 pb-12 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-500/10 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-purple-500/10 rounded-full blur-[100px] pointer-events-none" />

      <div className="container mx-auto px-6 relative z-10">
        <Link href="/deals" className="inline-flex items-center gap-2 text-slate-400 hover:text-white mb-8 transition-colors group">
          <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
          Back to Deals
        </Link>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-panel rounded-3xl overflow-hidden shadow-2xl"
        >
          {/* Header Banner */}
          <div className="h-48 bg-gradient-to-r from-blue-900/40 to-purple-900/40 relative">
             <div className="absolute inset-0 bg-grid-pattern opacity-20" />
          </div>

          <div className="px-8 pb-12 -mt-20 relative">
            <div className="flex flex-col md:flex-row gap-8 items-start">
                {/* Logo */}
                <div className="bg-white p-6 rounded-2xl w-40 h-40 flex items-center justify-center shadow-xl border border-white/10 shrink-0 relative z-10">
                     {deal.logoUrl ? (
                        <img src={deal.logoUrl} alt={deal.partnerName} className="w-full h-full object-contain" />
                     ) : (
                        <span className="text-slate-900 font-bold text-4xl">{deal.partnerName[0]}</span>
                     )}
                </div>
                
                {/* Header Content */}
                <div className="flex-1 pt-4 md:pt-20">
                    <div className="flex flex-wrap items-center gap-3 mb-2">
                        <span className="bg-blue-500/20 text-blue-300 px-3 py-1 rounded-full text-sm font-semibold border border-blue-500/20">
                            {deal.category}
                        </span>
                        {deal.isLocked && (
                            <span className="bg-yellow-500/20 text-yellow-300 px-3 py-1 rounded-full text-sm font-semibold border border-yellow-500/20 flex items-center gap-1">
                                <Lock size={14} /> Locked Deal
                            </span>
                        )}
                    </div>
                    
                    <h1 className="text-4xl md:text-5xl font-bold mb-2 text-white">{deal.title}</h1>
                    <p className="text-xl text-slate-300 font-medium mb-6">{deal.partnerName}</p>
                </div>

                {/* Action Box (Desktop) */}
                <div className="hidden md:block pt-20 w-80 shrink-0">
                    <div className="bg-slate-800/50 rounded-xl p-6 border border-white/5 backdrop-blur-md">
                        <h3 className="text-slate-300 font-semibold mb-4 text-center">Ready to save?</h3>
                        <button 
                            onClick={handleClaim}
                            disabled={!canClaim || claiming || (message?.type === 'success')}
                            className={clsx(
                                "w-full py-4 rounded-xl font-bold text-lg transition-all shadow-lg flex items-center justify-center gap-2",
                                canClaim 
                                ? "bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white hover:scale-[1.02] active:scale-[0.98]" 
                                : "bg-slate-700 text-slate-400 cursor-not-allowed"
                            )}
                        >
                            {claiming ? 'Processing...' : message?.type === 'success' ? 'Claimed Successfully' : canClaim ? 'Claim This Deal' : 'Locked'}
                        </button>
                        {!canClaim && (
                            <p className="mt-3 text-xs text-yellow-400 text-center bg-yellow-400/10 p-2 rounded">
                                Verification required to unlock
                            </p>
                        )}
                        {message && (
                            <div className={clsx("mt-4 p-3 rounded text-sm text-center font-medium", 
                                message.type === 'success' ? "bg-green-500/20 text-green-300" : "bg-red-500/20 text-red-300"
                            )}>
                                {message.text}
                            </div>
                        )}
                    </div>
                </div>
            </div>

            <div className="grid md:grid-cols-3 gap-12 mt-12">
                <div className="md:col-span-2 space-y-10">
                    <section>
                        <h3 className="text-2xl font-bold mb-4 flex items-center gap-2">
                            <ShieldCheck className="text-blue-400" /> About the Deal
                        </h3>
                        <div className="prose prose-invert prose-lg max-w-none text-slate-300 leading-relaxed">
                            <p>{deal.description}</p>
                        </div>
                    </section>

                    <section className="bg-slate-800/30 p-8 rounded-2xl border border-white/5">
                        <h3 className="text-xl font-bold mb-4 flex items-center gap-2 text-white">
                            <CheckCircle className="text-green-400" /> Eligibility Criteria
                        </h3>
                        <p className="text-slate-300">{deal.eligibility}</p>
                    </section>
                </div>

                <div className="space-y-6">
                    {/* Mobile Action Box */}
                    <div className="md:hidden">
                        <button 
                            onClick={handleClaim}
                            disabled={!canClaim || claiming || (message?.type === 'success')}
                            className={clsx(
                                "w-full py-4 rounded-xl font-bold text-lg transition-all shadow-lg mb-4",
                                canClaim 
                                ? "bg-blue-600 text-white" 
                                : "bg-slate-700 text-slate-400"
                            )}
                        >
                            {claiming ? 'Processing...' : message?.type === 'success' ? 'Claimed' : canClaim ? 'Claim Deal' : 'Locked'}
                        </button>
                         {message && (
                            <div className={clsx("p-3 rounded text-sm text-center font-medium mb-4", 
                                message.type === 'success' ? "bg-green-500/20 text-green-300" : "bg-red-500/20 text-red-300"
                            )}>
                                {message.text}
                            </div>
                        )}
                    </div>

                    <div className="glass-panel p-6 rounded-2xl">
                        <h4 className="font-bold text-slate-200 mb-4">Deal Information</h4>
                        <ul className="space-y-4">
                            <li className="flex items-center gap-3 text-slate-400">
                                <Globe size={18} />
                                <span>Global Availability</span>
                            </li>
                            <li className="flex items-center gap-3 text-slate-400">
                                <Calendar size={18} />
                                <span>Valid until Dec 2026</span>
                            </li>
                            <li className="flex items-center gap-3 text-slate-400">
                                <ShieldCheck size={18} />
                                <span>Verified Partner</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
