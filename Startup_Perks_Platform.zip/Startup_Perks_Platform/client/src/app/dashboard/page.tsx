'use client';

import { useState, useEffect } from 'react';
import api from '../../lib/api';
import { useAuth } from '../../context/AuthContext';
import { motion, AnimatePresence } from 'framer-motion';
import Link from 'next/link';
import { User, CheckCircle, Clock, ShieldAlert, DollarSign, Award, ArrowUpRight, X, Edit2 } from 'lucide-react';
import clsx from 'clsx';

interface Claim {
  _id: string;
  deal: {
    _id: string;
    title: string;
    partnerName: string;
    description: string;
  };
  status: string;
  claimedAt: string;
}

export default function Dashboard() {
  const [claims, setClaims] = useState<Claim[]>([]);
  const [loading, setLoading] = useState(true);
  const { user, updateUser } = useAuth();
  
  // Edit Profile State
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState('');
  const [editPassword, setEditPassword] = useState('');
  const [updateLoading, setUpdateLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  useEffect(() => {
    const fetchClaims = async () => {
      try {
        const { data } = await api.get('/claims/my-claims');
        setClaims(data);
      } catch (error) {
        console.error('Error fetching claims:', error);
      } finally {
        setLoading(false);
      }
    };
    if (user) fetchClaims();
  }, [user]);

  const handleEditClick = () => {
    if (user) {
        setEditName(user.name);
        setEditPassword('');
        setMessage(null);
        setIsEditing(true);
    }
  };

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setUpdateLoading(true);
    setMessage(null);
    try {
        const { data } = await api.put('/auth/profile', { 
            name: editName,
            ...(editPassword ? { password: editPassword } : {})
        });
        updateUser(data);
        setMessage({ type: 'success', text: 'Profile updated successfully' });
        setTimeout(() => {
            setIsEditing(false);
            setMessage(null);
        }, 1500);
    } catch (error: any) {
        setMessage({ type: 'error', text: error.response?.data?.message || 'Failed to update profile' });
    } finally {
        setUpdateLoading(false);
    }
  };

  if (!user) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-slate-950">
            <div className="text-center">
                <h2 className="text-2xl font-bold mb-4">Access Restricted</h2>
                <Link href="/login" className="text-blue-400 hover:underline">Please log in to view dashboard.</Link>
            </div>
        </div>
      );
  }

  // Mock stats (in a real app, calculate from actual deal values)
  const totalSavings = claims.length * 400000; // Mock ₹4L per deal
  const dealsClaimed = claims.length;

  return (
    <div className="min-h-screen bg-slate-950 pt-24 pb-12 relative overflow-hidden">
      <div className="absolute inset-0 z-0 bg-grid-pattern opacity-10 pointer-events-none" />
      
      {/* Edit Profile Modal */}
      <AnimatePresence>
        {isEditing && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
                <motion.div 
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="glass-panel w-full max-w-md rounded-2xl p-6 relative"
                >
                    <button 
                        onClick={() => setIsEditing(false)}
                        className="absolute top-4 right-4 text-slate-400 hover:text-white transition-colors"
                    >
                        <X size={20} />
                    </button>
                    
                    <h2 className="text-2xl font-bold mb-6">Edit Profile</h2>
                    
                    {message && (
                        <div className={clsx("p-3 rounded text-sm mb-4", 
                            message.type === 'success' ? "bg-green-500/20 text-green-300" : "bg-red-500/20 text-red-300"
                        )}>
                            {message.text}
                        </div>
                    )}

                    <form onSubmit={handleUpdateProfile} className="space-y-4">
                        <div>
                            <label className="block text-sm font-medium text-slate-400 mb-1">Name</label>
                            <input 
                                type="text" 
                                value={editName}
                                onChange={(e) => setEditName(e.target.value)}
                                className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 text-white"
                                required
                            />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-slate-400 mb-1">New Password (Optional)</label>
                            <input 
                                type="password" 
                                value={editPassword}
                                onChange={(e) => setEditPassword(e.target.value)}
                                className="w-full bg-slate-900/50 border border-slate-700 rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500 text-white"
                                placeholder="Leave blank to keep current"
                            />
                        </div>
                        <button 
                            type="submit"
                            disabled={updateLoading}
                            className="w-full bg-blue-600 hover:bg-blue-500 text-white py-3 rounded-lg font-bold transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {updateLoading ? 'Updating...' : 'Save Changes'}
                        </button>
                    </form>
                </motion.div>
            </div>
        )}
      </AnimatePresence>

      <div className="container mx-auto px-6 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid gap-8"
        >
          {/* Profile Header */}
          <div className="glass-panel p-8 rounded-3xl flex flex-col md:flex-row items-center md:items-start gap-6 border-l-4 border-l-blue-500">
             <div className="w-20 h-20 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-3xl font-bold shadow-lg">
                 {user.name[0]}
             </div>
             <div className="flex-1 text-center md:text-left">
                <h1 className="text-3xl font-bold mb-1">{user.name}</h1>
                <p className="text-slate-400 mb-4">{user.email}</p>
                <div className={clsx("inline-flex items-center gap-2 px-4 py-1.5 rounded-full text-sm font-medium border", 
                    user.isVerified ? "bg-green-500/10 border-green-500/20 text-green-400" : "bg-yellow-500/10 border-yellow-500/20 text-yellow-400"
                )}>
                    {user.isVerified ? <CheckCircle size={14} /> : <Clock size={14} />}
                    {user.isVerified ? 'Verified Startup' : 'Verification Pending'}
                </div>
             </div>
             <div className="flex gap-4">
                 <button 
                    onClick={handleEditClick}
                    className="bg-white/5 hover:bg-white/10 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors border border-white/10 flex items-center gap-2"
                 >
                     <Edit2 size={16} /> Edit Profile
                 </button>
             </div>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="glass-panel p-6 rounded-2xl relative overflow-hidden group">
                  <div className="absolute -right-6 -top-6 bg-green-500/20 w-24 h-24 rounded-full blur-2xl group-hover:bg-green-500/30 transition-colors" />
                  <div className="flex items-center gap-4 mb-2">
                      <div className="p-3 bg-green-500/10 rounded-lg text-green-400">
                          <DollarSign size={24} />
                      </div>
                      <span className="text-slate-400 font-medium">Total Savings</span>
                  </div>
                  <h3 className="text-3xl font-bold">₹{totalSavings.toLocaleString('en-IN')}</h3>
                  <p className="text-xs text-green-400 mt-2 flex items-center gap-1">
                      <ArrowUpRight size={12} /> Potential value
                  </p>
              </div>

              <div className="glass-panel p-6 rounded-2xl relative overflow-hidden group">
                  <div className="absolute -right-6 -top-6 bg-blue-500/20 w-24 h-24 rounded-full blur-2xl group-hover:bg-blue-500/30 transition-colors" />
                  <div className="flex items-center gap-4 mb-2">
                      <div className="p-3 bg-blue-500/10 rounded-lg text-blue-400">
                          <Award size={24} />
                      </div>
                      <span className="text-slate-400 font-medium">Deals Claimed</span>
                  </div>
                  <h3 className="text-3xl font-bold">{dealsClaimed}</h3>
                  <p className="text-xs text-slate-500 mt-2">Active perks</p>
              </div>

              <div className="glass-panel p-6 rounded-2xl relative overflow-hidden group">
                  <div className="absolute -right-6 -top-6 bg-purple-500/20 w-24 h-24 rounded-full blur-2xl group-hover:bg-purple-500/30 transition-colors" />
                  <div className="flex items-center gap-4 mb-2">
                      <div className="p-3 bg-purple-500/10 rounded-lg text-purple-400">
                          <ShieldAlert size={24} />
                      </div>
                      <span className="text-slate-400 font-medium">Next Milestone</span>
                  </div>
                  <h3 className="text-xl font-bold text-white">Series A Pack</h3>
                  <p className="text-xs text-slate-500 mt-2">Unlock at 5 claims</p>
              </div>
          </div>

          {/* Claims List */}
          <div>
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
                <Clock className="text-slate-500" size={24} /> Recent Activity
            </h2>
            
            {loading ? (
                <div className="space-y-4">
                    {[1, 2, 3].map(i => (
                        <div key={i} className="glass-panel h-20 rounded-xl animate-pulse" />
                    ))}
                </div>
            ) : claims.length === 0 ? (
                <div className="glass-panel p-12 rounded-2xl text-center border-dashed border-2 border-white/10">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-slate-800 mb-4">
                        <Award className="text-slate-500" size={32} />
                    </div>
                    <h3 className="text-xl font-bold mb-2">No deals claimed yet</h3>
                    <p className="text-slate-400 mb-6 max-w-md mx-auto">Start exploring our partner network to save money on your favorite tools.</p>
                    <Link href="/deals">
                        <button className="bg-white text-black px-6 py-2 rounded-full font-bold hover:bg-blue-50 transition-colors">
                            Browse Perks
                        </button>
                    </Link>
                </div>
            ) : (
                <div className="grid gap-4">
                    {claims.map((claim, idx) => (
                        <motion.div 
                            key={claim._id}
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            transition={{ delay: idx * 0.1 }}
                            className="glass-panel p-6 rounded-xl flex flex-col md:flex-row items-center justify-between gap-4 group hover:bg-white/10 transition-colors"
                        >
                            <div className="flex items-center gap-4 w-full md:w-auto">
                                <div className="w-12 h-12 rounded-lg bg-white/10 flex items-center justify-center font-bold text-xl">
                                    {claim.deal.partnerName[0]}
                                </div>
                                <div>
                                    <h3 className="font-bold text-lg">{claim.deal.title}</h3>
                                    <p className="text-slate-400 text-sm">{claim.deal.partnerName}</p>
                                </div>
                            </div>
                            
                            <div className="flex items-center gap-6 w-full md:w-auto justify-between md:justify-end">
                                <div className="text-right">
                                    <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Status</p>
                                    <span className={clsx("px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide",
                                        claim.status === 'approved' ? 'bg-green-500/20 text-green-400' : 
                                        claim.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-red-500/20 text-red-400'
                                    )}>
                                        {claim.status}
                                    </span>
                                </div>
                                <div className="text-right hidden sm:block">
                                    <p className="text-xs text-slate-500 uppercase tracking-wider mb-1">Date</p>
                                    <p className="text-sm font-medium text-slate-300">
                                        {new Date(claim.claimedAt).toLocaleDateString()}
                                    </p>
                                </div>
                                <button className="p-2 hover:bg-white/10 rounded-full transition-colors">
                                    <ArrowUpRight size={20} className="text-slate-400" />
                                </button>
                            </div>
                        </motion.div>
                    ))}
                </div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
