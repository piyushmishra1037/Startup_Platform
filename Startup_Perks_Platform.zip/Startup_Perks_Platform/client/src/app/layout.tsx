import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import { AuthProvider } from "../context/AuthContext";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "Startup Perks Platform",
  description: "Exclusive deals for startups",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className={`${inter.className} bg-slate-950 text-white min-h-screen flex flex-col`}>
        <div className="fixed inset-0 z-0 bg-grid-pattern opacity-20 pointer-events-none" />
        <div className="fixed top-0 left-0 w-full h-full z-0 pointer-events-none aurora-gradient opacity-20" />
        
        <AuthProvider>
          <Navbar />
          <main className="flex-grow relative z-10 pt-20">
             {children}
          </main>
          <Footer />
        </AuthProvider>
      </body>
    </html>
  );
}
