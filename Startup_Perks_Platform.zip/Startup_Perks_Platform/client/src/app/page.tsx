'use client';

import Link from 'next/link';
import ThreeHero from '../components/ThreeHero';
import { motion } from 'framer-motion';
import { ArrowRight, CheckCircle, Zap, Shield, Globe } from 'lucide-react';

const fadeIn = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 }
};

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

export default function Home() {
  return (
    <div className="relative min-h-screen flex flex-col overflow-hidden bg-slate-950">
      
      {/* Background Gradients */}
      <div className="absolute inset-0 z-0 bg-grid-pattern opacity-20 pointer-events-none" />
      <div className="absolute top-0 left-0 w-full h-full z-0 pointer-events-none aurora-gradient opacity-30" />

      {/* Hero Section */}
      <section className="relative z-10 min-h-screen flex flex-col items-center justify-center text-center px-4 pt-20">
        <div className="absolute inset-0 z-0">
             <ThreeHero />
        </div>
        
        <motion.div 
          initial="initial"
          animate="animate"
          variants={staggerContainer}
          className="z-10 max-w-4xl mx-auto space-y-8"
        >
          <motion.div variants={fadeIn} className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm text-sm font-medium text-blue-300 mb-4">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
            </span>
            New deals added weekly
          </motion.div>

          <motion.h1 variants={fadeIn} className="text-6xl md:text-8xl font-bold tracking-tight leading-tight">
            Scale Faster with <br />
            <span className="text-gradient">Exclusive Perks</span>
          </motion.h1>
          
          <motion.p variants={fadeIn} className="text-xl md:text-2xl text-slate-400 max-w-2xl mx-auto font-light leading-relaxed">
            Access over <span className="text-white font-semibold">₹40,00,000+</span> in savings on the best SaaS tools. 
            Verified deals for serious founders.
          </motion.p>
          
          <motion.div variants={fadeIn} className="flex flex-col sm:flex-row justify-center gap-4 pt-4">
            <Link href="/deals">
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="group bg-white text-black px-8 py-4 rounded-full font-bold text-lg hover:shadow-[0_0_30px_rgba(255,255,255,0.3)] transition-all flex items-center justify-center gap-2"
              >
                Explore Deals <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
              </motion.button>
            </Link>
            <Link href="/register">
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-4 rounded-full font-bold text-lg border border-white/20 bg-white/5 backdrop-blur-lg hover:bg-white/10 transition-colors"
              >
                Join for Free
              </motion.button>
            </Link>
          </motion.div>
        </motion.div>
      </section>

      {/* Trusted By Marquee */}
      <section className="py-10 border-y border-white/5 bg-black/20 backdrop-blur-sm z-10 overflow-hidden">
        <p className="text-center text-sm text-slate-500 mb-6 uppercase tracking-widest font-semibold">Trusted by founders from</p>
        <div className="flex gap-12 items-center justify-center opacity-50 grayscale hover:grayscale-0 transition-all duration-500 flex-wrap px-4">
           {/* Simple text placeholders for logos for now, or could use icons */}
           {['Y Combinator', 'TechStars', '500 Startups', 'Sequoia', 'Andreessen Horowitz'].map((name) => (
             <span key={name} className="text-xl font-bold text-white/40 hover:text-white/80 transition-colors cursor-default">{name}</span>
           ))}
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-32 relative z-10 max-w-7xl mx-auto px-6">
        <div className="text-center mb-20">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Why top startups choose us</h2>
          <p className="text-xl text-slate-400 max-w-2xl mx-auto">We negotiate the best deals so you can focus on building your product.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              icon: <Zap className="text-yellow-400" size={32} />,
              title: "Instant Access",
              desc: "No waiting periods. Get your codes immediately after verification."
            },
            {
              icon: <Shield className="text-blue-400" size={32} />,
              title: "Verified Deals",
              desc: "Every deal is tested and verified directly with partners."
            },
            {
              icon: <Globe className="text-purple-400" size={32} />,
              title: "Global Availability",
              desc: "Deals available for startups registered in over 100+ countries."
            }
          ].map((feature, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="glass-panel p-8 rounded-2xl hover:-translate-y-2 transition-transform duration-300 group"
            >
              <div className="bg-white/5 w-14 h-14 rounded-xl flex items-center justify-center mb-6 group-hover:bg-white/10 transition-colors border border-white/5">
                {feature.icon}
              </div>
              <h3 className="text-2xl font-bold mb-3">{feature.title}</h3>
              <p className="text-slate-400 leading-relaxed">{feature.desc}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 relative z-10 px-6 mb-20">
        <div className="max-w-5xl mx-auto rounded-3xl overflow-hidden relative">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600 to-purple-600 opacity-90" />
          <div className="absolute inset-0 bg-grid-pattern opacity-30 mix-blend-overlay" />
          
          <div className="relative p-12 md:p-20 text-center">
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-white">Ready to save thousands?</h2>
            <p className="text-xl text-blue-100 mb-10 max-w-2xl mx-auto">Join 10,000+ founders who are already scaling faster with our exclusive perk network.</p>
            <Link href="/register">
              <motion.button 
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-white text-blue-600 px-10 py-5 rounded-full font-bold text-xl shadow-xl hover:shadow-2xl transition-all"
              >
                Get Started Now
              </motion.button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
