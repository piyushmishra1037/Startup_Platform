'use client';

import Link from 'next/link';
import { useAuth } from '../context/AuthContext';
import { motion, useScroll, useMotionValueEvent } from 'framer-motion';
import { useState } from 'react';
import { Menu, X, Rocket, User, LogOut } from 'lucide-react';
import clsx from 'clsx';

const Navbar = () => {
  const { user, logout } = useAuth();
  const { scrollY } = useScroll();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useMotionValueEvent(scrollY, "change", (latest) => {
    setIsScrolled(latest > 50);
  });

  return (
    <>
      <motion.nav 
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className={clsx(
          "fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b",
          isScrolled 
            ? "bg-slate-950/70 backdrop-blur-md border-white/10 py-4 shadow-lg" 
            : "bg-transparent border-transparent py-6"
        )}
      >
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          <Link href="/" className="flex items-center gap-2 group">
            <div className="bg-blue-600 p-1.5 rounded-lg group-hover:rotate-12 transition-transform">
              <Rocket className="text-white" size={20} />
            </div>
            <span className="text-2xl font-bold tracking-tighter text-white">
              Startup<span className="text-blue-400">Perks</span>
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            <NavLink href="/deals">Explore Deals</NavLink>
            <NavLink href="/partners">Partners</NavLink>
            <NavLink href="/about">About</NavLink>
          </div>

          <div className="hidden md:flex items-center gap-4">
            {user ? (
              <div className="flex items-center gap-4">
                <Link href="/dashboard">
                  <motion.button 
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="flex items-center gap-2 text-sm font-medium text-slate-300 hover:text-white transition-colors"
                  >
                    <User size={18} /> Dashboard
                  </motion.button>
                </Link>
                <motion.button 
                  onClick={logout}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="bg-red-500/10 text-red-400 hover:bg-red-500/20 px-4 py-2 rounded-full text-sm font-semibold transition-colors border border-red-500/20 flex items-center gap-2"
                >
                  <LogOut size={16} /> Logout
                </motion.button>
              </div>
            ) : (
              <div className="flex items-center gap-4">
                <Link href="/login" className="text-slate-300 hover:text-white font-medium transition-colors">
                  Login
                </Link>
                <Link href="/register">
                  <motion.button 
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="bg-white text-slate-950 px-6 py-2.5 rounded-full font-bold text-sm hover:bg-blue-50 transition-colors shadow-[0_0_20px_rgba(255,255,255,0.2)]"
                  >
                    Get Started
                  </motion.button>
                </Link>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-white"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X /> : <Menu />}
          </button>
        </div>
      </motion.nav>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="fixed inset-0 z-40 bg-slate-950 pt-24 px-6 md:hidden"
        >
          <div className="flex flex-col gap-6 text-xl">
            <Link href="/deals" onClick={() => setMobileMenuOpen(false)}>Deals</Link>
            <Link href="/partners" onClick={() => setMobileMenuOpen(false)}>Partners</Link>
            <Link href="/about" onClick={() => setMobileMenuOpen(false)}>About</Link>
            <hr className="border-white/10" />
            {user ? (
              <>
                <Link href="/dashboard" onClick={() => setMobileMenuOpen(false)}>Dashboard</Link>
                <button onClick={logout} className="text-left text-red-400">Logout</button>
              </>
            ) : (
              <>
                <Link href="/login" onClick={() => setMobileMenuOpen(false)}>Login</Link>
                <Link href="/register" onClick={() => setMobileMenuOpen(false)} className="text-blue-400">Get Started</Link>
              </>
            )}
          </div>
        </motion.div>
      )}
    </>
  );
};

const NavLink = ({ href, children }: { href: string; children: React.ReactNode }) => (
  <Link href={href} className="text-sm font-medium text-slate-400 hover:text-white transition-colors relative group">
    {children}
    <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-blue-500 transition-all group-hover:w-full" />
  </Link>
);

export default Navbar;
