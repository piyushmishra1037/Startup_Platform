'use client';

import Link from 'next/link';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';
import { Lock, Unlock, ArrowRight } from 'lucide-react';
import clsx from 'clsx';
import { MouseEvent } from 'react';

interface DealProps {
  deal: {
    _id: string;
    title: string;
    description: string;
    partnerName: string;
    category: string;
    isLocked: boolean;
    logoUrl?: string;
  };
  isVerified: boolean;
}

const DealCard = ({ deal, isVerified }: DealProps) => {
  const isAccessible = !deal.isLocked || isVerified;

  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const mouseXSpring = useSpring(x);
  const mouseYSpring = useSpring(y);

  const rotateX = useTransform(mouseYSpring, [-0.5, 0.5], ["17.5deg", "-17.5deg"]);
  const rotateY = useTransform(mouseXSpring, [-0.5, 0.5], ["-17.5deg", "17.5deg"]);

  const handleMouseMove = (e: MouseEvent<HTMLDivElement>) => {
    const rect = (e.target as HTMLElement).getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    const xPct = mouseX / width - 0.5;
    const yPct = mouseY / height - 0.5;
    x.set(xPct);
    y.set(yPct);
  };

  const handleMouseLeave = () => {
    x.set(0);
    y.set(0);
  };

  return (
    <motion.div 
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{
        rotateX,
        rotateY,
        transformStyle: "preserve-3d",
      }}
      className={clsx(
        "relative glass-panel rounded-xl overflow-hidden p-6 transition-all perspective-1000 h-full flex flex-col group",
        !isAccessible && "opacity-75 grayscale-[0.3]"
      )}
    >
      <div style={{ transform: "translateZ(50px)" }} className="flex justify-between items-start mb-4">
        <div className="bg-white/10 w-12 h-12 rounded-lg flex items-center justify-center overflow-hidden shadow-lg border border-white/5">
             {/* Fallback or Image */}
             {deal.logoUrl ? <img src={deal.logoUrl} alt={deal.partnerName} className="w-full h-full object-contain" /> : <span className="text-xl font-bold">{deal.partnerName[0]}</span>}
        </div>
        <div className={clsx("px-2 py-1 rounded text-xs font-semibold flex items-center gap-1 shadow-sm border border-white/5", 
            deal.isLocked ? "bg-yellow-500/20 text-yellow-400" : "bg-green-500/20 text-green-400"
        )}>
            {deal.isLocked ? <Lock size={12} /> : <Unlock size={12} />}
            {deal.isLocked ? 'Locked' : 'Open'}
        </div>
      </div>

      <div style={{ transform: "translateZ(30px)" }} className="mb-4">
        <h3 className="text-xl font-bold mb-2 group-hover:text-blue-400 transition-colors">{deal.title}</h3>
        <p className="text-slate-400 text-sm line-clamp-2 leading-relaxed">{deal.description}</p>
      </div>
      
      <div style={{ transform: "translateZ(20px)" }} className="flex items-center justify-between mt-auto pt-4 border-t border-white/5">
        <span className="text-xs text-slate-500 bg-white/5 px-2 py-1 rounded border border-white/5">{deal.category}</span>
        
        <Link href={`/deals/${deal._id}`}>
            <button className={clsx(
                "flex items-center gap-1 text-sm font-semibold transition-colors hover:scale-105 active:scale-95",
                isAccessible ? "text-blue-400 hover:text-blue-300" : "text-slate-500 cursor-not-allowed"
            )}>
                View Details <ArrowRight size={14} />
            </button>
        </Link>
      </div>

      {deal.isLocked && !isVerified && (
          <div style={{ transform: "translateZ(60px)" }} className="absolute inset-0 flex items-center justify-center z-10 opacity-0 hover:opacity-100 transition-opacity bg-black/60 backdrop-blur-[2px] rounded-xl cursor-not-allowed">
              <div className="bg-slate-900/90 px-4 py-2 rounded-full border border-white/10 text-xs font-bold text-white shadow-xl flex items-center gap-2">
                  <Lock size={12} /> Verification Required
              </div>
          </div>
      )}
    </motion.div>
  );
};

export default DealCard;
