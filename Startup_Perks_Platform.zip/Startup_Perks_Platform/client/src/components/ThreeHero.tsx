'use client';

import { Canvas, useFrame } from '@react-three/fiber';
import { useRef } from 'react';
import { Mesh } from 'three';
import { Float, Environment } from '@react-three/drei';

function Cube(props: any) {
  const mesh = useRef<Mesh>(null!);
  
  useFrame((state, delta) => {
    mesh.current.rotation.x += delta * 0.2;
    mesh.current.rotation.y += delta * 0.2;
  });

  return (
    <Float speed={2} rotationIntensity={1.5} floatIntensity={2}>
      <mesh {...props} ref={mesh}>
        <boxGeometry args={[1, 1, 1]} />
        <meshStandardMaterial color={props.color} roughness={0.3} metalness={0.8} />
      </mesh>
    </Float>
  );
}

function Sphere(props: any) {
    const mesh = useRef<Mesh>(null!);
    
    useFrame((state, delta) => {
      mesh.current.position.y += Math.sin(state.clock.elapsedTime) * 0.002;
    });
  
    return (
      <Float speed={1.5} rotationIntensity={1} floatIntensity={2}>
        <mesh {...props} ref={mesh}>
          <sphereGeometry args={[0.7, 32, 32]} />
          <meshStandardMaterial color={props.color} roughness={0.2} metalness={0.9} />
        </mesh>
      </Float>
    );
  }

export default function ThreeHero() {
  return (
    <div className="absolute inset-0 -z-10">
      <Canvas camera={{ position: [0, 0, 5] }}>
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} intensity={1} />
        <Cube position={[-2, 1, 0]} color="#3b82f6" />
        <Cube position={[2, -1, -1]} color="#8b5cf6" />
        <Sphere position={[1.5, 1.5, -2]} color="#10b981" />
        <Environment preset="city" />
      </Canvas>
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-slate-950/50 to-slate-950 pointer-events-none" />
    </div>
  );
}
